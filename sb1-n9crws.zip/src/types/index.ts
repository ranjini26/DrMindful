export interface Game {
  id: string;
  title: string;
  description: string;
  duration: number;
  moodTags: string[];
  component: React.ComponentType;
}

export type Mood = 'stressed' | 'anxious' | 'unfocused' | 'tired' | 'energetic';